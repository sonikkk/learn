This sample app requires a video file to be placed in /sdcard/testfile.mp4
For demonstration purposes we have supplied such a file.
