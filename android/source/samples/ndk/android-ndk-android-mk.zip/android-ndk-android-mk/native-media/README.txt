This sample app requires an MPEG-2 Transport Stream file to be
placed in /sdcard/NativeMedia.ts and encoded as:

  video: H.264 baseline profile
  audio: AAC LC stereo

For demonstration purposes we have supplied such a .ts file.
Any actual stream must be created according to the MPEG-2 specification.
